enum LoginState {
    case idle
    case inProgress
}

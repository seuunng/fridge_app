//
//  flutter_naver_login_example.m
//  flutter_naver_login_example
//
//  Created by Seunggi KIM on 10/2/24.
//  Copyright © 2024 The Chromium Authors. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface flutter_naver_login_example : XCTestCase

@end

@implementation flutter_naver_login_example

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end

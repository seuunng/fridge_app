package com.yoonjaepark.flutter_naver_login

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import com.navercorp.nid.NaverIdLoginSDK
import com.navercorp.nid.oauth.NidOAuthLogin
import com.navercorp.nid.oauth.OAuthLoginCallback
import com.navercorp.nid.util.AndroidVer
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONException
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ExecutionException

/** FlutterNaverLoginPlugin */
class FlutterNaverLoginPlugin : FlutterPlugin, MethodCallHandler, ActivityAware {
    private var oAuthClientId = "OAUTH_CLIENT_ID"
    private var oAuthClientSecret = "OAUTH_CLIENT_SECRET"
    private var oAuthClientName = "OAUTH_CLIENT_NAME"

    private var channel: MethodChannel? = null
    private val mainScope = CoroutineScope(Dispatchers.Main)

    private var activity: Activity? = null
    private lateinit var launcher: ActivityResultLauncher<Intent>
    private var _applicationContext: Context? = null
    private val applicationContext get() = _applicationContext!!

    private var pendingResult: Result? = null

    override fun onAttachedToEngine(flutterPluginBinding: FlutterPlugin.FlutterPluginBinding) {
        _applicationContext = flutterPluginBinding.applicationContext
        channel = MethodChannel(flutterPluginBinding.binaryMessenger, "flutter_naver_login")
        channel?.setMethodCallHandler(this)

        NaverIdLoginSDK.showDevelopersLog(true)

        try {
            val bundle = flutterPluginBinding.applicationContext.packageManager?.getApplicationInfo(
                flutterPluginBinding.applicationContext.packageName,
                PackageManager.GET_META_DATA
            )?.metaData

            bundle?.let {
                oAuthClientId = it.getString("com.naver.sdk.clientId").toString()
                oAuthClientSecret = it.getString("com.naver.sdk.clientSecret").toString()
                oAuthClientName = it.getString("com.naver.sdk.clientName").toString()
                try {
                    NaverIdLoginSDK.initialize(
                        flutterPluginBinding.applicationContext,
                        oAuthClientId,
                        oAuthClientSecret,
                        oAuthClientName
                    )
                } catch (e: Exception) {
                    deleteCurrentEncryptedPreferences(flutterPluginBinding.applicationContext)
                    NaverIdLoginSDK.initialize(
                        flutterPluginBinding.applicationContext,
                        oAuthClientId,
                        oAuthClientSecret,
                        oAuthClientName
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        _applicationContext = null
        channel?.setMethodCallHandler(null)
        channel = null
    }

    override fun onAttachedToActivity(binding: ActivityPluginBinding) {
        this.activity = binding.activity

        binding.addActivityResultListener { requestCode, resultCode, data ->
            if (requestCode == NAVER_LOGIN_REQUEST_CODE) {
                handleActivityResult(resultCode, data)
                true
            } else {
                false
            }
        }
    }

    private fun handleActivityResult(resultCode: Int, data: Intent?) {
        if (pendingResult != null) {
            when (resultCode) {
                Activity.RESULT_OK -> {
                    mainScope.launch {
                        getCurrentAccount(pendingResult!!)
                    }
                }
                Activity.RESULT_CANCELED -> {
                    val errorCode = NaverIdLoginSDK.getLastErrorCode().code
                    val errorDesc = NaverIdLoginSDK.getLastErrorDescription()
                    pendingResult!!.success(mapOf("status" to "error", "errorMessage" to "errorCode:$errorCode, errorDesc:$errorDesc"))
                }
                else -> {
                    pendingResult!!.success(null)
                }
            }
        }
        pendingResult = null
    }

    companion object {
        private const val NAVER_LOGIN_REQUEST_CODE = 1001
    }

    override fun onReattachedToActivityForConfigChanges(binding: ActivityPluginBinding) {
        onAttachedToActivity(binding)
    }

    override fun onDetachedFromActivityForConfigChanges() {
        onDetachedFromActivity()
    }

    override fun onDetachedFromActivity() {
        this.activity = null
    }

    override fun onMethodCall(call: MethodCall, result: Result) {
        when (call.method) {
            "logIn" -> this.login(result)
            "logOut" -> this.logout(result)
            "getCurrentAccessToken" -> this.getCurrentAccessToken(result)
            else -> result.notImplemented()
        }
    }
    private fun logout(result: Result) {
        try {
            NaverIdLoginSDK.logout()
            result.success(mapOf("status" to "cancelledByUser", "isLogin" to false))
        } catch (e: Exception) {
            e.printStackTrace()
            result.error("LOGOUT_ERROR", "로그아웃 중 오류 발생", null)
        }
    }
    private fun login(result: Result) {
        pendingResult = result

        val mOAuthLoginHandler = object : OAuthLoginCallback {
            override fun onSuccess() {
                mainScope.launch {
                    getCurrentAccount(result)
                }
            }

            override fun onFailure(httpStatus: Int, message: String) {
                val errorCode = NaverIdLoginSDK.getLastErrorCode().code
                val errorDesc = NaverIdLoginSDK.getLastErrorDescription()
                result.success(mapOf("status" to "error", "errorMessage" to "errorCode:$errorCode, errorDesc:$errorDesc"))
            }

            override fun onError(errorCode: Int, message: String) {
                onFailure(errorCode, message)
            }
        }
        NaverIdLoginSDK.authenticate(this.activity!!, mOAuthLoginHandler)
    }

    suspend fun getCurrentAccount(result: Result) {
        val accessToken = NaverIdLoginSDK.getAccessToken()

        try {
            val res = getUserInfo(accessToken ?: "")
            val obj = JSONObject(res)
            val resultProfile = jsonObjectToMap(obj.getJSONObject("response"))
            resultProfile["status"] = "loggedIn"
            result.success(resultProfile)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private suspend fun getUserInfo(token: String): String = withContext(Dispatchers.IO) {
        val header = "Bearer $token"
        try {
            val apiURL = "https://openapi.naver.com/v1/nid/me"
            val url = URL(apiURL)
            val con = url.openConnection() as HttpURLConnection
            con.requestMethod = "GET"
            con.setRequestProperty("Authorization", header)
            val responseCode = con.responseCode
            val br: BufferedReader = if (responseCode == 200) {
                BufferedReader(InputStreamReader(con.inputStream))
            } else {
                BufferedReader(InputStreamReader(con.errorStream))
            }
            val response = br.use(BufferedReader::readText)
            br.close()
            response
        } catch (e: Exception) {
            e.printStackTrace()
            ""
        }
    }

    private fun getCurrentAccessToken(result: Result) {
        val accessToken = NaverIdLoginSDK.getAccessToken()
        val refreshToken = NaverIdLoginSDK.getRefreshToken()
        val expiresAt = NaverIdLoginSDK.getExpiresAt().toString()
        val tokenType = NaverIdLoginSDK.getTokenType()

        val tokenInfo = mutableMapOf<String, String>()
        tokenInfo["status"] = "getToken"
        if (accessToken != null) tokenInfo["accessToken"] = accessToken
        if (refreshToken != null) tokenInfo["refreshToken"] = refreshToken
        tokenInfo["expiresAt"] = expiresAt
        if (tokenType != null) tokenInfo["tokenType"] = tokenType

        result.success(tokenInfo)
    }

    private fun deleteCurrentEncryptedPreferences(context: Context) {
        val oauthLoginPrefNamePerApp = "NaverOAuthLoginEncryptedPreferenceData"
        val oldOauthLoginPrefName = "NaverOAuthLoginPreferenceData"

        if (Build.VERSION.SDK_INT >= AndroidVer.API_24_NOUGAT) {
            try {
                println("- try clear old oauth login prefs")
                context.deleteSharedPreferences(oldOauthLoginPrefName)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        try {
            println("- try clear shared oauth login prefs")
            val preferences = context.getSharedPreferences(oauthLoginPrefNamePerApp, Context.MODE_PRIVATE)
            val edit = preferences.edit()
            edit.clear()
            edit.apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @Throws(JSONException::class)
    fun jsonObjectToMap(jObject: JSONObject): HashMap<String, String> {
        val map = HashMap<String, String>()
        val keys = jObject.keys()

        while (keys.hasNext()) {
            val key = keys.next() as String
            val value = jObject.getString(key)
            map[key] = value
        }
        return map
    }
}
